For Question 1 :
	Main Verilog File : 
		lfsr.v
	Main Testbench :
		test_lfsr.v

For Question 2 : 
	Main Verilog File :
		two_compl.v
	Main Testbench :
		test_2scomplement.v

For Question 3 :
	Main Verilog File :
		multThree.v
	Main Testbench :
		test_mult3.v

For Question 4:
	Main Verilog File :
		seqcompwithreg.v
	Main Testbench :
		master_testbench.v